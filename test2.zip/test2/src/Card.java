public enum Card {
    BLACK,
    WHITE,
    EMPTY
}
