import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

public class Main {

    public static void main(String[] args) {

        AStar aStar = new AStar();
        aStar.begin();
    }
}
